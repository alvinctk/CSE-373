
public class VertexSet {
	int vertices [];
	int size;
	
	public VertexSet(int size){
		this (size, new int[size]);
		for(int i = 0; i < size; i++){
		   vertices[i] = i;
		}
	}

	public VertexSet(int size, int [] vertices){
		this.size = size; 
		this.vertices = vertices;
	}
	
	public VertexSet(VertexSet toBeCopy, int indexToBeRemove){
		this(toBeCopy.size-1, new int[toBeCopy.size-1]);
		int i = 0; 
		int copyMe [] = toBeCopy.vertices;
		for (i =0; i < indexToBeRemove; i++){
			vertices[i] = copyMe[i];
		}
		for (int j = i; j < size; j++){
			vertices[j] = copyMe[j + 1];
		}
		
	}
}
